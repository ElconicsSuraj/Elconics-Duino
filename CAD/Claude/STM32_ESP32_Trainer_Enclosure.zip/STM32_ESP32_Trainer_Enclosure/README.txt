STM32 + ESP32 TRAINER ENCLOSURE  (fits KiCad board 125 x 135 mm)
Outer size: 131 x 147 x 29.4 mm

PARTS TO PRINT
  base.stl        x1  (print as-is, floor down)      - dark colour
  lid.stl         x1  (print FLIPPED, top face down)  - white/light colour
  button_cap.stl  x6  (print upright)                 - red/accent colour
  PLA/PETG, 0.2 mm layers, 3 walls, 20% infill. No supports needed for base;
  lid printed face-down needs no supports (tabs/posts point up).

ASSEMBLY (tool-less, snap-fit)
  1. Drop PCB onto the 4 standoffs - locating pins go through the M3 holes.
  2. Put the 6 button caps into the lid from underneath (flange stops them).
  3. Press lid straight down: 8 cantilever hooks click into wall windows.
     The 4 lid posts clamp the PCB down on the standoffs.
  To open: push hooks in through the side windows with a small screwdriver.

CUTOUTS
  LCD 16x2  - flush bezel window 71.0 x 25.0, chamfered
  OLED 0.96 - window over active area + light shroud down to the glass
  PWR IN    - screw terminal fully open from the side + top (screwdriver access)
  USB-C / Micro-USB - front wall, recessed for plug overmolds
  micro-SD  - right wall slot with finger scoop
  All headers, IDC 2x10, DIP switch, pot (screwdriver guide), buzzer grill,
  6 LED light-pipes, RGB LED window, rear + floor vents, rubber-foot pockets.

Labels (K1..K6, GPIO-L, etc.) are engraved 0.5 mm - fill with paint/wax or
use a filament swap to make them pop. Edit names in enclosure.py (labels list)
and re-run:  pip install cadquery ; python enclosure.py
