"""
STM32 + ESP32 Trainer Board enclosure  (parametric, CadQuery)
All XY coordinates are the PCB coordinates from the KiCad STEP (board 125 x 135 mm).
Z: base floor bottom = 0. PCB bottom sits at ZB.
"""
import cadquery as cq

# ---------------- global parameters ----------------
T      = 2.4      # wall thickness
FLOOR  = 2.4      # floor thickness
STAND  = 9.0      # PCB standoff height (clears 32kHz crystal leads at -6.9)
PCB_T  = 1.6
ZB     = FLOOR + STAND          # PCB bottom (11.4)
ZT     = ZB + PCB_T             # PCB top (13.0)
LID_GAP= 15.6                   # lid underside above PCB bottom (tallest part 15.4)
ZL     = ZB + LID_GAP           # lid underside / top of base walls (27.0)
LID_T  = 2.4
ZTOP   = ZL + LID_T             # 29.4
CLR    = 0.25                   # sliding clearance lid lip <-> wall
R_OUT  = 6.0

# inner cavity (PCB 0..125 x 0..135, ESP32 antenna & LCD overhang to y=140.94)
IX0, IX1, IY0, IY1 = -0.6, 125.6, -0.6, 141.6
OX0, OX1, OY0, OY1 = IX0 - T, IX1 + T, IY0 - T, IY1 + T
OW, OH = OX1 - OX0, OY1 - OY0
OCX, OCY = (OX0 + OX1) / 2, (OY0 + OY1) / 2
IW, IH = IX1 - IX0, IY1 - IY0
ICX, ICY = (IX0 + IX1) / 2, (IY0 + IY1) / 2

HOLES = [(4.5, 4.5), (120.5, 4.5), (4.5, 130.5), (120.5, 130.5)]

def pz(z):  # PCB-relative z -> enclosure z
    return ZB + z

def box(x0, x1, y0, y1, z0, z1):
    return (cq.Workplane("XY").box(x1 - x0, y1 - y0, z1 - z0)
            .translate(((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2)))

def rbox(x0, x1, y0, y1, z0, z1, r):
    w = cq.Workplane("XY").box(x1 - x0, y1 - y0, z1 - z0)
    if r > 0:
        w = w.edges("|Z").fillet(r)
    return w.translate(((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2))

def cyl(x, y, z0, z1, d):
    return cq.Workplane("XY").circle(d / 2).extrude(z1 - z0).translate((x, y, z0))

# ---------------- snap tab layout ----------------
# (wall, position along wall). Chosen to stay clear of OLED, IDC, terminal block.
TABS = [("front", 12), ("front", 62), ("rear", 30), ("rear", 92),
        ("left", 30), ("left", 125), ("right", 62), ("right", 118)]
TAB_W, TAB_T, TAB_L = 10.0, 1.4, 8.0
BARB = 0.9
WIN_Z0, WIN_Z1 = ZL - TAB_L + 0.6, ZL - TAB_L + 2.1   # window in base wall

# ======================================================
#                       BASE
# ======================================================
def make_base():
    outer = rbox(OX0, OX1, OY0, OY1, 0, ZL, R_OUT)
    outer = outer.faces("<Z").edges().fillet(1.6)
    inner = rbox(IX0, IX1, IY0, IY1, FLOOR, ZL + 1, 1.0)
    base = outer.cut(inner)

    # standoffs with locating pins
    for (x, y) in HOLES:
        s = cyl(x, y, FLOOR - 0.1, ZB, 7.0)
        pin = (cq.Workplane("XY").circle(1.45).extrude(PCB_T + 1.2)
               .faces(">Z").chamfer(0.4).translate((x, y, ZB)))
        gus = cyl(x, y, FLOOR - 0.1, FLOOR + 2.0, 10.0)
        base = base.union(s).union(pin).union(gus)

    # --- FRONT wall: USB-C (2171790001) and Micro-USB (10118192-0001LF)
    for (x0, x1, z0, z1, rw, rh) in [(21.0, 31.0, 0.8, 5.4, 14.0, 9.5),
                                     (42.5, 51.5, 1.0, 4.6, 12.5, 8.0)]:
        cx, cz = (x0 + x1) / 2, pz((z0 + z1) / 2)
        hole = (cq.Workplane("XZ").rect(x1 - x0, z1 - z0).extrude(-10)
                .edges("|Y").fillet(1.2).translate((cx, OY0 - 1, cz)))
        rec = (cq.Workplane("XZ").rect(rw, rh).extrude(-1.0)
               .edges("|Y").fillet(2.0).translate((cx, OY0 - 0.01, cz)))
        base = base.cut(hole).cut(rec)

    # --- LEFT wall: terminal block wire entry (open U-notch, lid also opens here)
    base = base.cut(box(OX0 - 1, IX0 + 1, 48.6, 60.4, pz(3.0), ZL + 1))

    # --- RIGHT wall: micro-SD slot + finger scoop
    sd = (cq.Workplane("YZ").rect(13.0, 3.0).extrude(10)
          .edges("|X").fillet(1.0).translate((IX1 - 1, 34.3, pz(2.9))))
    scoop = (cq.Workplane("YZ").circle(9).extrude(5)
             .translate((OX1 - 1.2, 34.3, pz(2.9))))
    base = base.cut(sd).cut(scoop.intersect(box(OX1 - 1.2, OX1 + 4, 20, 50, pz(-2), pz(8))))

    # --- REAR wall: vent slots
    for i in range(9):
        x = 28 + i * 6.5
        v = (cq.Workplane("XZ").rect(2.4, 9).extrude(-10).edges("|Y").fillet(1.1)
             .translate((x, IY1 - 1, 16.5)))
        base = base.cut(v)

    # --- snap windows
    for wall, p in TABS:
        zc, hz = (WIN_Z0 + WIN_Z1) / 2, WIN_Z1 - WIN_Z0
        if wall == "front":
            w = box(p - 5.5, p + 5.5, OY0 - 1, IY0 + 0.5, WIN_Z0, WIN_Z1)
        elif wall == "rear":
            w = box(p - 5.5, p + 5.5, IY1 - 0.5, OY1 + 1, WIN_Z0, WIN_Z1)
        elif wall == "left":
            w = box(OX0 - 1, IX0 + 0.5, p - 5.5, p + 5.5, WIN_Z0, WIN_Z1)
        else:
            w = box(IX1 - 0.5, OX1 + 1, p - 5.5, p + 5.5, WIN_Z0, WIN_Z1)
        base = base.cut(w)

    # --- bottom: rubber-foot pockets, vents, engraved text
    for (x, y) in [(OX0 + 10, OY0 + 10), (OX1 - 10, OY0 + 10),
                   (OX0 + 10, OY1 - 10), (OX1 - 10, OY1 - 10)]:
        base = base.cut(cyl(x, y, -1, 1.0, 12.5))
    for i in range(7):
        y = 20 + i * 5.5
        base = base.cut(rbox(40, 90, y - 1.2, y + 1.2, -1, FLOOR + 1, 1.15))
    txt = (cq.Workplane("XY").text("STM32 + ESP32 TRAINER  |  REV A", 5, 0.6,
                                   combine=False, halign="center", valign="center")
           .mirror("YZ").translate((62.5, 85, 0)))
    base = base.cut(txt.translate((0, 0, -0.01)))
    return base

# ======================================================
#                        LID
# ======================================================
HEADER_CUTS = [  # PCB-coordinate rectangles (already include ~0.3 clearance)
    (5.2, 13.85, 22.3, 37.6),     # 4x 1x03 jumper headers
    (19.5, 22.7, 39.4, 80.6),     # 1x16 GPIO left
    (67.6, 70.6, 39.4, 80.6),     # 1x16 GPIO right
    (24.9, 66.1, 82.9, 86.05),    # 1x16 expansion
    (15.65, 18.8, 75.15, 80.8),   # 1x02
    (4.73, 12.87, 68.0, 78.8),    # 1x04 hdr + 1x04 socket
    (23.25, 26.35, 48.2, 53.85),  # 1x02
    (92.6, 98.2, 29.05, 32.15),   # 1x02 header
    (85.8, 88.95, 71.0, 86.85),   # 1x06
    (75.05, 78.15, 77.0, 85.25),  # 1x03
    (118.15, 121.25, 113.85, 119.5),  # 1x02 near ESP32
    (0.99, 11.1, 80.56, 114.62),  # 2x10 IDC (JTAG/SWD)
    (57.57, 64.68, 90.35, 100.85),# DIP switch
]
LCD_WIN  = (18.55, 89.55, 105.35, 130.35)    # LCD bezel (70.4 x 24.4) + 0.3
OLED_WIN = (81.6, 103.8, 10.1, 21.5)          # OLED active area + margin
TB_CUT   = (OX0 - 1, 10.6, 48.6, 60.4)        # terminal block (open to side)
BUTTONS  = [(87.4, 50.0), (87.4, 58.5), (87.4, 67.0),
            (97.78, 107.0), (109.94, 107.0), (19.5, 91.0)]
BTN_HOLE = 6.9
LEDS     = [(18.0, 31.7), (34.4, 31.7), (15.4, 18.0), (3.5, 18.0),
            (28.7, 91.1), (31.7, 91.1)]
RGB      = (60.23, 11.4)
POT      = (80.61, 78.965)
BUZZ     = (47.5, 94.5)

def engrave_text(lid, s, x, y, size, angle=0, depth=0.5, font="Sans", bold=True):
    t = cq.Workplane("XY").text(s, size, -depth, combine=False, halign="center",
                                valign="center", kind="bold" if bold else "regular")
    t = t.rotate((0, 0, 0), (0, 0, 1), angle).translate((x, y, ZTOP + 0.01))
    return lid.cut(t)

def engrave_frame(lid, x0, x1, y0, y1, w=0.6, depth=0.4, r=1.5):
    o = rbox(x0, x1, y0, y1, ZTOP - depth, ZTOP + 1, r)
    i = rbox(x0 + w, x1 - w, y0 + w, y1 - w, ZTOP - depth - 1, ZTOP + 2, max(r - w, 0.2))
    return lid.cut(o.cut(i))

def make_lid():
    lid = rbox(OX0, OX1, OY0, OY1, ZL, ZTOP, R_OUT)
    lid = lid.faces(">Z").edges().fillet(1.8)

    # locating lip (continuous ring, broken at tabs and terminal block)
    lip_o = rbox(IX0 + CLR, IX1 - CLR, IY0 + CLR, IY1 - CLR, ZL - 3.5, ZL + 0.1, 0.75)
    lip_i = rbox(IX0 + CLR + 1.6, IX1 - CLR - 1.6, IY0 + CLR + 1.6, IY1 - CLR - 1.6,
                 ZL - 5, ZL + 1, 0.3)
    lip = lip_o.cut(lip_i).cut(box(IX0 - 1, IX0 + 4, 46.0, 63.0, ZL - 6, ZL))
    for wall, p in TABS:
        if wall == "front":
            lip = lip.cut(box(p - 6.5, p + 6.5, IY0 - 1, IY0 + 3, ZL - 6, ZL))
        elif wall == "rear":
            lip = lip.cut(box(p - 6.5, p + 6.5, IY1 - 3, IY1 + 1, ZL - 6, ZL))
        elif wall == "left":
            lip = lip.cut(box(IX0 - 1, IX0 + 3, p - 6.5, p + 6.5, ZL - 6, ZL))
        else:
            lip = lip.cut(box(IX1 - 3, IX1 + 1, p - 6.5, p + 6.5, ZL - 6, ZL))
    lid = lid.union(lip)

    # cantilever snap tabs with barbs
    for wall, p in TABS:
        z0 = ZL - TAB_L
        prof = (cq.Workplane("XZ")  # barb profile in local (u=outward, z)
                .polyline([(0, z0), (BARB, z0 + 1.2), (BARB, z0 + 2.0), (0, z0 + 2.0)]).close()
                .extrude(TAB_W / 2, both=True))
        arm = box(-TAB_T, 0, -TAB_W / 2, TAB_W / 2, z0, ZL + 0.1)
        tab = arm.union(prof)            # outward = +X in local frame
        if wall == "front":
            tab = tab.rotate((0, 0, 0), (0, 0, 1), -90).translate((p, IY0 + CLR, 0))
        elif wall == "rear":
            tab = tab.rotate((0, 0, 0), (0, 0, 1), 90).translate((p, IY1 - CLR, 0))
        elif wall == "left":
            tab = tab.rotate((0, 0, 0), (0, 0, 1), 180).translate((IX0 + CLR, p, 0))
        else:
            tab = tab.translate((IX1 - CLR, p, 0))
        lid = lid.union(tab)

    # PCB clamp posts (receive standoff pins)
    for (x, y) in HOLES:
        post = cyl(x, y, ZT + 0.05, ZL + 0.1, 7.0).cut(cyl(x, y, ZT, ZT + 2.4, 3.4))
        lid = lid.union(post)

    # button guide collars
    for (x, y) in BUTTONS:
        lid = lid.union(cyl(x, y, pz(13.6), ZL + 0.1, 9.2))
    # OLED light shroud
    x0, x1, y0, y1 = OLED_WIN
    sh = rbox(x0 - 1.2, x1 + 1.2, y0 - 1.2, y1 + 1.2, pz(12.15), ZL + 0.1, 1.2)
    lid = lid.union(sh)
    # pot screwdriver guide
    lid = lid.union(cyl(*POT, pz(10.6), ZL + 0.1, 6.5))
    # LED light tubes
    for (x, y) in LEDS:
        lid = lid.union(cyl(x, y, pz(3.4), ZL + 0.1, 4.2))
    lid = lid.union(cyl(*RGB, pz(3.0), ZL + 0.1, 5.4))

    # ---------------- cutouts ----------------
    def window(x0, x1, y0, y1, ch=1.0, r=1.0, zlow=ZB):
        w = rbox(x0, x1, y0, y1, zlow, ZTOP + 1, r)
        c = (cq.Workplane("XY").rect(x1 - x0, y1 - y0).workplane(offset=ch + 0.01)
             .rect(x1 - x0 + 2 * ch, y1 - y0 + 2 * ch).loft()
             .translate(((x0 + x1) / 2, (y0 + y1) / 2, ZTOP - ch)))
        return w.union(c)

    lid = lid.cut(window(*LCD_WIN, ch=1.2, r=0.8))
    lid = lid.cut(window(*OLED_WIN, ch=1.2, r=0.6))
    for (x0, x1, y0, y1) in HEADER_CUTS:
        lid = lid.cut(window(x0, x1, y0, y1, ch=0.6, r=0.4))
    lid = lid.cut(box(*TB_CUT, ZB, ZTOP + 1))
    for (x, y) in BUTTONS:
        lid = lid.cut(cyl(x, y, ZB, ZTOP + 1, BTN_HOLE))
        lid = lid.cut(cq.Workplane("XY").circle(BTN_HOLE / 2).workplane(offset=0.8)
                      .circle(BTN_HOLE / 2 + 0.8).loft().translate((x, y, ZTOP - 0.8)))
    lid = lid.cut(cyl(*POT, ZB, ZTOP + 1, 3.6))
    lid = lid.cut(cq.Workplane("XY").circle(1.8).workplane(offset=1.2).circle(3.2)
                  .loft().translate((POT[0], POT[1], ZTOP - 1.2)))
    for (x, y) in LEDS:
        lid = lid.cut(cyl(x, y, ZB, ZTOP + 1, 2.3))
    lid = lid.cut(cyl(*RGB, ZB, ZTOP + 1, 3.4))
    # buzzer grill
    bx, by = BUZZ
    pts = [(0, 0)] + [(3.2 * __import__("math").cos(a * 1.0472), 3.2 * __import__("math").sin(a * 1.0472)) for a in range(6)] \
        + [(5.8 * __import__("math").cos(a * 0.5236 + 0.26), 5.8 * __import__("math").sin(a * 0.5236 + 0.26)) for a in range(12)]
    for (dx, dy) in pts:
        lid = lid.cut(cyl(bx + dx, by + dy, ZB, ZTOP + 1, 1.8))

    # ---------------- trainer-panel graphics ----------------
    lid = engrave_frame(lid, OX0 + 3.2, OX1 - 3.2, OY0 + 3.2, OY1 - 3.2, w=0.8, depth=0.5, r=3.5)
    lid = engrave_frame(lid, LCD_WIN[0] - 2.5, LCD_WIN[1] + 2.5, LCD_WIN[2] - 2.5, LCD_WIN[3] + 2.5)
    lid = engrave_frame(lid, OLED_WIN[0] - 3.0, OLED_WIN[1] + 3.0, OLED_WIN[2] - 3.0, OLED_WIN[3] + 6.2)
    lid = engrave_frame(lid, 81.5, 99.5, 44.3, 72.8)       # key column
    lid = engrave_frame(lid, 93.0, 116.5, 99.0, 112.6)     # ESP keys

    labels = [
        ("STM32 + ESP32", 54.0, 18.0, 5.0, 0),
        ("TRAINER KIT", 45.0, 9.0, 3.2, 0),
        ("RGB", 66.5, 11.4, 2.4, 0),
        ("USB-C", 26.0, 2.6, 2.4, 0),
        ("MICRO USB", 47.0, 2.6, 2.4, 0),
        ("LCD 16x2", 54.0, 134.6, 3.2, 0),
        ("OLED 0.96", 92.7, 25.4, 2.6, 0),
        ("ESP32 WiFi/BT", 104.0, 132.0, 2.6, 0),
        ("STM32F401", 45.0, 61.0, 3.6, 0),
        ("K1", 95.0, 50.0, 2.6, 0), ("K2", 95.0, 58.5, 2.6, 0), ("K3", 95.0, 67.0, 2.6, 0),
        ("K4", 97.78, 101.0, 2.4, 0), ("K5", 109.94, 101.0, 2.4, 0),
        ("K6", 19.5, 83.6, 2.4, 0),
        ("JP1-4", 9.5, 40.0, 2.4, 0),
        ("GPIO-L", 16.8, 66.0, 2.4, 90),
        ("GPIO-R", 73.4, 60.0, 2.4, 90),
        ("EXPANSION", 45.0, 80.0, 2.4, 0),
        ("JTAG / SWD", 13.8, 104.0, 2.4, 90),
        ("DIP", 66.6, 95.6, 2.4, 90),
        ("BUZZER", 38.6, 94.5, 2.4, 90),
        ("POT", 81.6, 74.4, 2.4, 0),
        ("PWR IN", 13.6, 54.5, 2.4, 90),
        ("SD CARD", 121.6, 34.3, 2.4, 90),
    ]
    for (s, x, y, sz, a) in labels:
        lid = engrave_text(lid, s, x, y, sz, a)
    return lid

# ======================================================
#                    BUTTON CAP (print x6)
# ======================================================
def make_cap():
    push = cq.Workplane("XY").circle(1.7).extrude(12.3 - 6.05).translate((0, 0, 6.05))
    flange = cq.Workplane("XY").circle(4.0).extrude(1.2).translate((0, 0, 12.3))
    shaft = (cq.Workplane("XY").circle(3.2).extrude(19.4 - 13.5)
             .faces(">Z").edges().fillet(1.0).translate((0, 0, 13.5)))
    cap = push.union(flange).union(shaft)
    return cap.translate((0, 0, -6.05))   # local: bottom at z=0

if __name__ == "__main__":
    import sys
    base = make_base();  print("base ok")
    lid = make_lid();    print("lid ok")
    cap = make_cap();    print("cap ok")
    import pickle
    for n, w in [("base", base), ("lid", lid), ("button_cap", cap)]:
        cq.exporters.export(w, f"out/{n}.step")
        cq.exporters.export(w, f"out/{n}.stl", tolerance=0.05, angularTolerance=0.15)
        print(n, w.val().isValid(), round(w.val().Volume() / 1000, 1), "cm3")
